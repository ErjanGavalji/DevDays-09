﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;

[ServiceContract(Namespace = "")]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public class NorthwindData
{
	// Add [WebGet] attribute to use HTTP GET
	[OperationContract]
    [WebGet]
	public IQueryable<Product> GetProducts()
	{
        NorthwindDataContext data = new NorthwindDataContext();
		return data.Products;
	}

	// Add more operations here and mark them with [OperationContract]
}
