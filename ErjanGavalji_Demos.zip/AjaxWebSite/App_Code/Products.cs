﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Collections;

/// <summary>
/// Summary description for Products
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[ScriptService]
public class Products : System.Web.Services.WebService {

    public Products () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public IEnumerable GetProducts(int categoryID) {
        NorthwindDataContext data = new NorthwindDataContext();
        var productData = from p in data.Products where p.CategoryID == categoryID
                          select
                             new
                             {
                                 ProductName = p.ProductName,
                                 ProductID = p.ProductID
                             };
        return productData;
    }

    [WebMethod]
    public void Update(List<Change<ProductDefinition>> changeSet)
    {
        NorthwindDataContext data = new NorthwindDataContext();
        foreach (Change<ProductDefinition> change in changeSet)
        {
            switch (change.action)
            {
                //case ChangeType.insert:
                //    break;
                //case ChangeType.remove:
                //    break;
                case ChangeType.update:
                    UpdateProduct(data, change.item);
                    break;
            }
        }
        data.SubmitChanges();
    }

    private void UpdateProduct(NorthwindDataContext data, ProductDefinition product)
    {
        Product updatedProduct = data.Products.First(p => p.ProductID == product.ProductID);
        updatedProduct.ProductName = product.ProductName;
    }
}

