﻿namespace Telerik.Mvc.Web.Helpers
{
	/// <summary>
	/// Data storage class used for the charts
	/// </summary>
	public class PostPerDay
	{
		public int Posts { get; set; }
		public string Day { get; set; }
	}
}
