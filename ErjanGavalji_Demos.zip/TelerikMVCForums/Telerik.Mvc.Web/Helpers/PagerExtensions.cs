﻿using System;
using System.Text;
using System.Web.Mvc;
using System.Web.Routing;

namespace Telerik.Mvc.Web.Helpers
{
	/// <summary>
	/// Contains extension methods for rendering pagers
	/// </summary>
	public static class PagerExtensions
	{
		/// <summary>
		/// Renders a numeric pager
		/// </summary>
		/// <param name="htmlHelper">The HtmlHelper object being extended</param>
		/// <param name="pageRouteKey">The key in the RouteTable which contains the current page index</param>
		/// <param name="context">The current ViewContext</param>
		/// <param name="currentPage">The current page</param>
		/// <param name="totalNumberOfItems">The total number of items being paged</param>
		/// <param name="pageSize">Size of the page (items per page)</param>
		/// <returns></returns>
		public static string NumericPager(this HtmlHelper htmlHelper, string pageRouteKey, 
			ViewContext context, int currentPage, int totalNumberOfItems, int pageSize)
		{
			var totalPages = (int)Math.Ceiling(totalNumberOfItems / (float)pageSize);

			if (totalPages <= 1)
				return String.Empty;

			var pager = new StringBuilder();
			for (var page = 0; page < totalPages; page++)
			{
				if (page != currentPage)
				{
					context.RouteData.Values[pageRouteKey] = page;
					pager.AppendFormat("<a href=\"{0}\">{1}</a>",
						RouteTable.Routes.GetVirtualPath(context.RequestContext, context.RouteData.Values).VirtualPath,
					    page + 1
					);
				}
				else
				{
					pager.Append(page + 1);
				}
			}

			return pager.ToString();
		}
	}
}
