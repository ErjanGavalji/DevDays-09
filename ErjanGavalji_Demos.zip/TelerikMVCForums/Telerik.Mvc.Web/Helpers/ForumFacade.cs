﻿using System;
using System.Collections.Generic;
using System.Web.Security;
using Telerik.Mvc.Model;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Query;

namespace Telerik.Mvc.Web.Helpers
{
	/// <summary>
	/// Provides simpler API to the persistent classes
	/// </summary>
	public static class ForumFacade
	{
		/// <summary>
		/// Returns all forum categories
		/// </summary>
		public static IList<Category> GetAllCategories(IObjectScope scope)
		{
			return (from category in scope.Extent<Category>() select category).ToList();
		}

		/// <summary>
		/// Returns specific <see cref="Category" /> by its <see cref="Category.Url" />
		/// </summary>
		public static Category GetCategory(IObjectScope scope, string categoryUrl)
		{
			if (string.IsNullOrEmpty(categoryUrl))
				return null;

			return (from category in scope.Extent<Category>()
					where category.Url == categoryUrl
					select category).FirstOrDefault();
		}

		/// <summary>
		/// Returns specific <see cref="Forum" /> object based on its category and <see cref="Forum.Url"/>
		/// </summary>
		public static Forum GetForum(IObjectScope scope, string categoryUrl, string forumUrl)
		{
			if (string.IsNullOrEmpty(forumUrl))
				return null;

			return (from forum in scope.Extent<Forum>()
					where forum.Url == forumUrl &&
					forum.Category.Url == categoryUrl
					select forum).FirstOrDefault();
		}

		/// <summary>
		/// Returns the currently logged <see cref="User"/>
		/// </summary>
		public static User GetCurrentUser(IObjectScope scope, string userName)
		{
			var userId = ((User)Membership.Provider.GetUser(userName, true).ProviderUserKey).Id;

			return (from user in scope.Extent<User>()
					where user.Id == userId
					select user).FirstOrDefault();
		}

		/// <summary>
		/// Creates a new forum thread in the specified forum
		/// </summary>
		public static void CreateThread(IObjectScope scope, Forum forum, string title, string content, User author)
		{
			var date = DateTime.Now;

			var friendlyUrl = title.Trim().Replace(" ", "-").ToLower();

			var thread = new Thread
			{
				Author = author,
				CreatedDate = date,
				Forum = forum,
				Title = title,
				Url = friendlyUrl
			};

			var post = new Post
			{
				Author = author,
				Content = content,
				CreatedDate = date,
				Thread = thread
			};

			thread.Posts = new List<Post>();
			thread.Posts.Add(post);

			scope.Transaction.Begin();
			forum.Threads.Add(thread);
			scope.Transaction.Commit();
		}

		/// <summary>
		/// Creates a new post in the specified thread
		/// </summary>
		public static void CreatePost(IObjectScope scope, Thread thread, string content, User author)
		{
			var post = new Post
			{
				Author = author,
				Content = content,
				Thread = thread,
				CreatedDate = DateTime.Now
			};

			scope.Transaction.Begin();
			scope.Add(post);
			scope.Transaction.Commit();
		}

		/// <summary>
		/// Returns specific <see cref="Thread"/> based on the category, forum and <see cref="Thread.Url"/>
		/// </summary>
		public static Thread GetThread(IObjectScope scope, string categoryUrl, string forumUrl, string threadUrl)
		{
			if (string.IsNullOrEmpty(threadUrl))
				return null;

			return (from thread in scope.Extent<Thread>()
					where thread.Forum.Url == forumUrl &&
					thread.Forum.Category.Url == categoryUrl &&
					thread.Url == threadUrl
					select thread).FirstOrDefault();
		}
	}
}