﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Web;
using Telerik.Mvc.Model;

namespace Telerik.Mvc.Web.Helpers
{
	/// <summary>
	/// The AvatarHelper class contains methods needed for handling avatars. 
	/// Avatar images are stored in the file system.
	/// The avatars of the built-in users are stored in ~/Images/default". 
	/// The avatars of newly registered users are stored in ~/Images.
	/// The format of avatar file names is as follows:
	/// userId.png where userID is the ID of the <see cref="User"/> object in GUID format
	/// </summary>
	public static class AvatarHelper
	{
		//The name of the default avatar image used when there is no specific avatar defined for some user.
		public const string DefaultAvatar = "avatar.gif";
		//The folder where avatar images are stored
		public const string AvatarFolder = "~/Images/";
		//The folder where the default avatars are stored - those include avatars for the built-in users and the default image.
		public static readonly string DefaultAvatarFolder = VirtualPathUtility.Combine(AvatarFolder, "default");

		public const int ThumbnailHeight = 80;
		public const int ThumbnailWidth = 80;

		/// <summary>
		/// Returns true if the user has avatar (not the default one)
		/// </summary>
		public static bool UserHasAvatar(HttpContext context, Guid userId)
		{
			return !VirtualPathUtility.GetFileName(Avatar(context, userId)).EndsWith(DefaultAvatar);
		}

		/// <summary>
		/// Returns the virtual path to the avatar of the specified user.
		/// </summary>
		/// <remarks>
		///	First probes in "~/Images" then in "~/Images/Default". If no file in the format userId.png exists in those locations the
		/// default avatar is returned.
		/// </remarks>
		public static string Avatar(HttpContext context, Guid userId)
		{
			var avatarFileName = MakeFileName(userId);
			var avatarPhysicalLocation = Path.Combine(context.Server.MapPath(AvatarFolder), avatarFileName);

			if (File.Exists(avatarPhysicalLocation))
				return VirtualPathUtility.ToAbsolute(AvatarFolder + "/" + avatarFileName);

			avatarPhysicalLocation = Path.Combine(context.Server.MapPath(DefaultAvatarFolder), avatarFileName);

			if (File.Exists(avatarPhysicalLocation))
				return VirtualPathUtility.ToAbsolute(DefaultAvatarFolder + "/" + avatarFileName);

			return VirtualPathUtility.ToAbsolute(DefaultAvatarFolder + "/" + DefaultAvatar);
		}

		/// <summary>
		/// Appends the "png" extension to the specified user id. This is the format for storing avatars
		/// </summary>
		private static string MakeFileName(Guid userId)
		{
			return userId + ".png";
		}

		/// <summary>
		/// Saves a thumbnail of the uploaded avatar image
		/// </summary>
		public static void SaveAvatarThumbnail(HttpContextBase context, Guid userId, HttpPostedFileBase file)
		{
			using (var originalImage = new Bitmap(file.InputStream))
			{
				var ratio = originalImage.Width / (double)originalImage.Height;

				var thumbnailHeight = ThumbnailHeight;
				var thumbnailWidth = ThumbnailWidth;

				if (originalImage.Height > originalImage.Width)
					thumbnailHeight = Convert.ToInt32(thumbnailHeight * ratio);
				else
					thumbnailWidth = Convert.ToInt32(thumbnailWidth / ratio);

				using (var thumbnail = new Bitmap(thumbnailHeight, thumbnailWidth))
				{
					using (var g = Graphics.FromImage(thumbnail))
					{
						g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
						g.DrawImage(originalImage, 0, 0, thumbnailHeight, thumbnailWidth);
						thumbnail.Save(Path.Combine(context.Server.MapPath(AvatarFolder), MakeFileName(userId)),
							ImageFormat.Png);
					}
				}
			}
		}

		/// <summary>
		/// Deletes the avatar for the specified user
		/// </summary>
		public static void DeleteAvatar(HttpContextBase context, Guid userId)
		{
			var path = context.Server.MapPath(AvatarFolder);
			var avatarPhysicalLocation = Path.Combine(path, MakeFileName(userId));

			if (File.Exists(avatarPhysicalLocation))
				File.Delete(avatarPhysicalLocation);
		}
	}
}
