﻿using System.Web.Mvc;
using System.Web.Routing;

namespace Telerik.Mvc.Web
{
	// Note: For instructions on enabling IIS6 or IIS7 classic mode, 
	// visit http://go.microsoft.com/?LinkId=9394801

	public class MvcApplication : System.Web.HttpApplication
	{
		public static void RegisterRoutes(RouteCollection routes)
		{
			routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

			routes.MapRoute(
				"Category",
				"forum/{categoryUrl}/{categoryPage}",
				new { controller = "Category", action = "Index", categoryPage = 0 },
				new { categoryPage = @"\d+" }
			);

			routes.MapRoute(
				"Forum",
				"forum/{categoryUrl}/{forumUrl}/{forumPage}",
				new { controller = "Forum", action = "Index", forumPage = 0 },
				new { forumPage = @"\d+" }
			);

			routes.MapRoute(
				"Post",
				"forum/{categoryUrl}/{forumUrl}/post",
				new { controller = "Forum", action = "Post" }
				);

			routes.MapRoute(
				"PostSubmit",
				"forum/{categoryUrl}/{forumUrl}/post/submit",
				new { controller = "Forum", action = "Submit" }
				);

			routes.MapRoute(
				"Reply",
				"forum/{categoryUrl}/{forumUrl}/{threadUrl}/reply/{threadPage}",
				new { controller = "Thread", action = "Reply", threadPage = 0 },
				new { threadPage = @"\d+" }
			);
			
			routes.MapRoute(
				"Thread",
				"forum/{categoryUrl}/{forumUrl}/{threadUrl}/{threadPage}",
				new { controller = "Thread", action = "Index", threadPage = 0 },
				new { threadPage = @"\d+" }
			);


			routes.MapRoute(
				"ReplySubmit",
				"forum/{categoryUrl}/{forumUrl}/{threadUrl}/reply/submit",
				new { controller = "Thread", action = "Submit" }
			);

			routes.MapRoute(
				"Home",
				"forums/{forumPage}",
				new { controller = "Home", action = "Index", forumPage = 0 },
				new { forumPage = @"\d+" }
			);

			routes.MapRoute(
			    "Default", // Route name
			    "{controller}/{action}", // URL with parameters
			    new {controller = "Home", action = "Index"} // Parameter defaults
			 );
		}

		protected void Application_Start()
		{
			RegisterRoutes(RouteTable.Routes);
			//RouteDebug.RouteDebugger.RewriteRoutesForTesting(RouteTable.Routes);
		}
	}
}