﻿namespace Telerik.Mvc.Web.Views.Thread
{
	public partial class BreadCrumb : System.Web.Mvc.ViewUserControl<Model.Thread>
	{
	}
}
