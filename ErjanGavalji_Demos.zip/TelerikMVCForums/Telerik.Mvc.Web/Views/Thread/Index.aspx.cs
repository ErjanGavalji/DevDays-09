﻿using System.Web.Mvc;


namespace Telerik.Mvc.Web.Views.Thread
{
	public partial class Index : ViewPage<Model.Thread>
	{
	}
}
