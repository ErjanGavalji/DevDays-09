﻿namespace Telerik.Mvc.Web.Views.Forum
{
	public partial class BreadCrumb : System.Web.Mvc.ViewUserControl<Model.Forum>
	{
	}
}
