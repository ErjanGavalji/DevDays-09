﻿using System.Web.Mvc;

namespace Telerik.Mvc.Web.Views.Forum
{
	public partial class Post : ViewPage<Model.Forum>
	{
	}
}
