﻿using System.Web.Mvc;

namespace Telerik.Mvc.Web.Views.Forum
{
	public partial class Index : ViewPage<Model.Forum>
	{
	}
}
