﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace Telerik.Mvc.Web.Views.Home
{
    public partial class Index : ViewPage<IList<Model.Category>>
    {
    }
}
