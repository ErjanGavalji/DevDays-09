﻿namespace Telerik.Mvc.Web.Views.Category
{
	public partial class BreadCrumb : System.Web.Mvc.ViewUserControl<Model.Category>
	{
	}
}
