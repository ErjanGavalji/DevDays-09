﻿using System.Web.Mvc;


namespace Telerik.Mvc.Web.Views.Category
{
	public partial class Index : ViewPage<Model.Category>
	{
	}
}
