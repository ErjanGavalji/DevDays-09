﻿using System.Web.Mvc;
using Telerik.Mvc.Model;


namespace Telerik.Mvc.Web.Views.Account
{
    public partial class Settings : ViewPage<User>
    {

    }
}
