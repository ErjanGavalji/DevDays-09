﻿using System.Collections.Generic;

namespace Telerik.Mvc.Web.Views.Shared
{
	public partial class NavigationTreeView : System.Web.Mvc.ViewUserControl<IList<Model.Category>>
	{
	}
}
