﻿using System.Collections.Generic;

namespace Telerik.Mvc.Web.Views.Shared
{
	public partial class MenuControl : System.Web.Mvc.ViewUserControl<IList<Model.Category>>
    {
    }
}
