﻿using System.Web.Mvc;
using Telerik.Mvc.Web.Helpers;

namespace Telerik.Mvc.Web.Controllers
{
	/// <summary>
	/// CategoryController is responsible for displaying the forums in a specific forum category
	/// </summary>
	public class CategoryController : ControllerBase
	{
		public ActionResult Index(string categoryUrl, int categoryPage)
		{
			var category = ForumFacade.GetCategory(Scope, categoryUrl);
			
			if (category == null)
				return RedirectToAction("Index", "Home");

			ViewData["PageIndex"] = categoryPage;
			
			return View("Index", category);
		}
	}
}