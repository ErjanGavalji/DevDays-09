﻿using System.Web.Mvc;
using Telerik.Mvc.Web.Helpers;
using Telerik.OpenAccess;

namespace Telerik.Mvc.Web.Controllers
{
	/// <summary>
	/// Base class for all controller classes.
	/// </summary>
	/// <remarks>
	///		Serves two things:
	///		<list>
	///			<item>
	///				Maintains the current OpenAccess ObjectScope
	///			</item>
	///			<item>
	///				Retrieves a list of all forum categories which are then displayed in the treeview navigation
	///			</item>
	///		</list>
	/// </remarks>
	public abstract class ControllerBase : Controller
	{
		private IObjectScope scope;

		public IObjectScope Scope
		{
			get { return (scope = scope ?? ModelObjectScopeProvider.GetNewObjectScope()); }
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && scope != null)
				scope.Dispose();

			base.Dispose(disposing);
		}

		protected override void OnResultExecuting(ResultExecutingContext filterContext)
		{
			filterContext.Controller.ViewData["Categories"] = ForumFacade.GetAllCategories(Scope);
			base.OnResultExecuting(filterContext);
		}
	}
}
