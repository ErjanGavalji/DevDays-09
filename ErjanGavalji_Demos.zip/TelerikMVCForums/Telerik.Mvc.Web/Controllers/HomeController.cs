﻿using System.Web.Mvc;
using Telerik.Mvc.Web.Helpers;
using Telerik.OpenAccess;
using Telerik.Web.UI;

namespace Telerik.Mvc.Web.Controllers
{
    /// <summary>
    /// The HomeController is responsible for 
    /// </summary>
	[HandleError]
    public class HomeController : ControllerBase
    {
		/// <summary>
		/// Displays the initial screen
		/// </summary>
		public ActionResult Index(int? forumPage)
        {
			ViewData["PageIndex"] = forumPage ?? 0;
			return View("Index", ForumFacade.GetAllCategories(Scope));
        }

        /// <summary>
		/// Displays the help page
        /// </summary>
		public ActionResult Help()
        {
			ViewData["RadControlsVersion"] = typeof(RadControl).Assembly.GetName().Version.ToString();
			ViewData["OpenAccessVersion"] = typeof(IObjectScope).Assembly.GetName().Version.ToString();
			return View();
        }
    }
}
