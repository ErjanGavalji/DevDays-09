﻿using System.Web.Mvc;
using Telerik.Mvc.Web.Helpers;

namespace Telerik.Mvc.Web.Controllers
{
	/// <summary>
	/// The ThreadController class is responsible for displaying the posts in a forum thread and the reply logic
	/// </summary>
	public class ThreadController : ControllerBase
	{
		/// <summary>
		/// Creates a new post in a forum thread
		/// </summary>
		[Authorize]
		[AcceptVerbs(HttpVerbs.Post)]
		public ActionResult Submit(string categoryUrl, string forumUrl, string threadUrl)
		{
			var thread = ForumFacade.GetThread(Scope, categoryUrl, forumUrl, threadUrl);

			if (thread == null)
				return RedirectToAction("Index", "Home");

			var htmlContent = RadControlHelper.ExtractHtmlValue(Request, "RadEditor1");

			if (string.IsNullOrEmpty(htmlContent))
			{
				ModelState.AddModelError("_FORM", "Content of the post cannot be empty");
				return View("Reply", thread);
			}

			ForumFacade.CreatePost(
				Scope,
				thread,
				htmlContent,
				ForumFacade.GetCurrentUser(Scope, User.Identity.Name)
			);

			return RedirectToAction("Index", "Thread");
		}
		
		/// <summary>
		/// Shows the UI for creating a forum post
		/// </summary>
		[Authorize]
		public ActionResult Reply(string categoryUrl, string forumUrl, string threadUrl, int threadPage)
		{
			var thread = ForumFacade.GetThread(Scope, categoryUrl, forumUrl, threadUrl);

			if (thread == null)
				return RedirectToAction("Index", "Home");
			
			ViewData["PageIndex"] = threadPage;

			return View("Reply", thread);
		}

		/// <summary>
		/// Shows the posts in a forum thread.
		/// </summary>
		public ActionResult Index(string categoryUrl, string forumUrl, string threadUrl, int threadPage)
		{
			var thread = ForumFacade.GetThread(Scope, categoryUrl, forumUrl, threadUrl);

			if (thread == null)
				return RedirectToAction("Index", "Home");

			ViewData["PageIndex"] = threadPage;

			return View("Index", thread);
		}
	}
}