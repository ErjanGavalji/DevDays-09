﻿using System.Web.Mvc;
using Telerik.Mvc.Web.Helpers;

namespace Telerik.Mvc.Web.Controllers
{
	/// <summary>
	/// The ForumController class is responsible for displaying the threads in a forum and posting new threads
	/// </summary>
	public class ForumController : ControllerBase
	{
		//Called when the user clicks the "Post" button
		[Authorize]
		public ActionResult Post(string categoryUrl, string forumUrl)
		{
			var forum = ForumFacade.GetForum(Scope, categoryUrl, forumUrl);
			
			if (forum == null)
				return RedirectToAction("Index", "Home");

			return View("Post", forum);
		}

		//Called when the user creates a new forum thread
		[Authorize]
		[AcceptVerbs(HttpVerbs.Post)]
		public ActionResult Submit(string categoryUrl, string forumUrl, string title)
		{
			var forum = ForumFacade.GetForum(Scope, categoryUrl, forumUrl);
			
			if (forum == null)
				return RedirectToAction("Index", "Home");

			if (string.IsNullOrEmpty(title))
			{
				ModelState.AddModelError("_FORM", "Thread title is required");
				return View("Post", forum);
			}
			
			var htmlContent = RadControlHelper.ExtractHtmlValue(Request, "RadEditor1");

			if (string.IsNullOrEmpty(htmlContent))
			{
				ModelState.AddModelError("_FORM", "Thread content is required");
				return View("Post", forum);
			}

			ForumFacade.CreateThread(Scope, 
				forum, 
				title, 
				htmlContent, 
				ForumFacade.GetCurrentUser(Scope, User.Identity.Name)
			);

			return RedirectToAction("Index");
		}

		public ActionResult Index(string categoryUrl, string forumUrl, int forumPage)
		{
			var forum = ForumFacade.GetForum(Scope, categoryUrl, forumUrl);

			if (forum == null)
				return RedirectToAction("Index", "Home");
			
			ViewData["PageIndex"] = forumPage;
			
			return View("Index", forum);
		}
	}
}