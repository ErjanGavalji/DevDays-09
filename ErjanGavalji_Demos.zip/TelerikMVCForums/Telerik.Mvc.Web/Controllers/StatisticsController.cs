﻿using System.Linq;
using System.Web.Mvc;
using Telerik.Mvc.Model;
using Telerik.Mvc.Web.Helpers;
using Telerik.OpenAccess.Query;

namespace Telerik.Mvc.Web.Controllers
{
	/// <summary>
	/// The StatisticsController class is responsible for displaying various statistics data
	/// </summary>
	public class StatisticsController : ControllerBase
	{
		public ActionResult Index()
		{
			ViewData["TotalUsers"] = Scope.GetOqlQuery("select count(*) from UserExtent").Execute()[0];

			ViewData["TotalThreads"] = Scope.GetOqlQuery("select count(*) from ThreadExtent").Execute()[0];

			ViewData["TotalPosts"] = Scope.GetOqlQuery("select count(*) from PostExtent").Execute()[0];

			var posts = from post in Scope.Extent<Post>() select post;

			ViewData["PostsPerDay"] = (from p in posts.ToList()
                  group p by p.CreatedDate.Date
                  into g select new PostPerDay {
					Posts = g.Count(),
					Day = g.Key.ToShortDateString()
				  }).ToList();
			
			ViewData["PostsPerTechnology"] = 
				Scope.GetOqlQuery("select count(*), p.thread.forum.category.name  from PostExtent as p group by p.thread.forum.category.name")
				.Execute();
			
			return View();
		}
	}
}
