﻿using System;
using System.Collections.Specialized;
using System.Configuration;
using System.Security.Cryptography;
using System.Text;
using System.Web.Configuration;
using System.Web.Security;
using Telerik.Mvc.Model;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Query;

namespace Telerik.Mvc.Providers
{
	/// <summary>
	/// Membership provider which uses OpenAccess for storing user data.
	/// </summary>
	/// <remarks>
	/// At the time being the provider is very basic and provides only login and registration capabilities.
	/// </remarks>
	public class OpenAccessMembershipProvider : MembershipProvider
	{
		/// <summary>
		/// Reference to the OpenAccess DataBase object
		/// </summary>
		private Database database;

		/// <summary>
		/// Contains the machine key in string form - used for computing hashes
		/// </summary>
		private string machineKey;

		/// <summary>
		/// The id of the OpenAccess connection
		/// </summary>
		private string ConnectionId { get; set; }

		private Database MembershipDatabase
		{
			get
			{
				if (database == null)
					database = Database.Get(ConnectionId);
				return database;
			}
		}

		public override void Initialize(string name, NameValueCollection config)
		{
			base.Initialize(name, config);
			//Initialize the ConnectionID property from the "connectionName" xml attribute of the provider
			ConnectionId = config["connectionName"];

			//Read the machineKey from the configuration file (machine key is most of the time defined in machine.config)
			var machineKeySection = (MachineKeySection)ConfigurationManager.GetSection("system.web/machineKey");
			machineKey = machineKeySection.ValidationKey;
		}

		public override MembershipUser CreateUser(string username, string password, string email,
												  string passwordQuestion, string passwordAnswer, bool isApproved,
												  object providerUserKey, out MembershipCreateStatus status)
		{
			var scope = MembershipDatabase.GetObjectScope();

			if (RequiresUniqueEmail && !String.IsNullOrEmpty(GetUserNameByEmail(email)))
			{
				status = MembershipCreateStatus.DuplicateEmail;
				return null;
			}

			if (GetUser(username, true) != null)
			{
				status = MembershipCreateStatus.DuplicateUserName;
				return null;
			}

			try
			{
				//Set RetainValues to true so the User object is available after closing the scope
				scope.TransactionProperties.RetainValues = true;

				scope.Transaction.Begin();

				//Create a new Model.User object (this is our persistent class)
				var user = new User
				{
					UserName = username,
					Email = email,
					PasswordHash = HashString(password),
					BirthDay = DateTime.Now
				};

				//Add the user and commit the transaction. This would push the new user to the database.
				scope.Add(user);
				scope.Transaction.Commit();

				status = MembershipCreateStatus.Success;

				return new MembershipUser(Name,
					  user.UserName,
					  user,
					  user.Email,
					  null,
					  null,
					  true,
					  false,
					  DateTime.MinValue,
					  DateTime.MinValue,
					  DateTime.MinValue,
					  DateTime.MinValue,
					  DateTime.MinValue
				);
			}
			catch (OpenAccessException)
			{
				status = MembershipCreateStatus.ProviderError;
				throw;
			}
			finally
			{
				scope.Dispose();
			}
		}

		/// <summary>
		/// Hashes the specified string using SHA1
		/// </summary>
		/// <param name="value"></param>
		/// <returns>The SHA1 hash of the specified argument</returns>
		private string HashString(string value)
		{
			var hash = new HMACSHA1 {
           		Key = Encoding.UTF8.GetBytes(machineKey)
           	};

			return Convert.ToBase64String(
				hash.ComputeHash(Encoding.UTF8.GetBytes(value))
			);
		}

		public override bool ChangePassword(string username, string oldPassword, string newPassword)
		{
			using (var scope = MembershipDatabase.GetObjectScope())
			{
				//Get the user whith the same user name
				var user = (from u in scope.Extent<User>()
							where u.UserName == username
							select u).FirstOrDefault();

				scope.Transaction.Begin();
				//Update his password and push the changes to the database
				user.PasswordHash = HashString(newPassword);
				scope.Transaction.Commit();
				return true;
			}
		}

		public override bool ValidateUser(string email, string password)
		{
			using (var scope = MembershipDatabase.GetObjectScope())
			{
				var hashedPassword = HashString(password);
				
				//Select a user based on email and password
				return (from user in scope.Extent<User>()
						where user.Email == email &&
							  user.PasswordHash == hashedPassword
						select user).FirstOrDefault() != null;
			}
		}

		public override MembershipUser GetUser(string username, bool userIsOnline)
		{
			using (var scope = MembershipDatabase.GetObjectScope())
			{
				//Get the user based on his username
				var user = (from u in scope.Extent<User>()
							 where u.UserName == username
							 select u).FirstOrDefault();

				if (user == null)
					return null;

				return new MembershipUser(Name,
					  user.UserName,
					  user,
					  user.Email,
					  null,
					  null,
					  true,
					  false,
					  DateTime.MinValue,
					  DateTime.MinValue,
					  DateTime.MinValue,
					  DateTime.MinValue,
					  DateTime.MinValue
				);
			}
		}

		public override bool RequiresUniqueEmail
		{
			get { return true; }
		}

		public override MembershipPasswordFormat PasswordFormat
		{
			get { return MembershipPasswordFormat.Hashed; }
		}

		public override int MinRequiredPasswordLength
		{
			get { return 6; }
		}

		public override string GetUserNameByEmail(string email)
		{
			using (var scope = MembershipDatabase.GetObjectScope())
			{
				return (from user in scope.Extent<User>() where user.Email == email select user.UserName).FirstOrDefault();
			}
		}

		#region Not implemented methods from the MembershipProvider class
		public override bool UnlockUser(string userName)
		{
			throw new NotImplementedException();
		}

		public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
		{
			throw new NotImplementedException();
		}

		public override string ResetPassword(string username, string answer)
		{
			throw new NotImplementedException();
		}

		public override void UpdateUser(MembershipUser user)
		{
			throw new NotImplementedException();
		}

		public override bool ChangePasswordQuestionAndAnswer(string username, string password,
															 string newPasswordQuestion, string newPasswordAnswer)
		{
			throw new NotImplementedException();
		}

		public override string GetPassword(string username, string answer)
		{
			throw new NotImplementedException();
		}

		public override bool DeleteUser(string username, bool deleteAllRelatedData)
		{
			throw new NotImplementedException();
		}

		public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
		{
			throw new NotImplementedException();
		}

		public override int GetNumberOfUsersOnline()
		{
			throw new NotImplementedException();
		}

		public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize,
																 out int totalRecords)
		{
			throw new NotImplementedException();
		}

		public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize,
																  out int totalRecords)
		{
			throw new NotImplementedException();
		}

		public override bool EnablePasswordRetrieval
		{
			get { throw new NotImplementedException(); }
		}

		public override bool EnablePasswordReset
		{
			get { throw new NotImplementedException(); }
		}

		public override bool RequiresQuestionAndAnswer
		{
			get { throw new NotImplementedException(); }
		}

		public override string ApplicationName
		{
			get { throw new NotImplementedException(); }
			set { throw new NotImplementedException(); }
		}

		public override int MaxInvalidPasswordAttempts
		{
			get { throw new NotImplementedException(); }
		}

		public override int PasswordAttemptWindow
		{
			get { throw new NotImplementedException(); }
		}


		public override int MinRequiredNonAlphanumericCharacters
		{
			get { throw new NotImplementedException(); }
		}

		public override string PasswordStrengthRegularExpression
		{
			get { throw new NotImplementedException(); }
		}
		#endregion
	}
}