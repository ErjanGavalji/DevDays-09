﻿using System;
using Telerik.OpenAccess;

namespace Telerik.Mvc.Model
{
    /// <summary>
    /// Represents a registered forum user. At the time being all users are equal - there are no roles and administration.
    /// </summary>
	[Persistent(IdentityField = "id")]
    public class User
    {
        private Guid id;
        private string userName;
        private string email;
        private string passwordHash;
    	private DateTime birthDay;

        /// <summary>
		/// The unique id of the user. Used as a primary key in the database.
        /// </summary>
		[FieldAlias("id")]
		public Guid Id
        {
            get { return id; }
            set { id = value; }
        }
        
		/// <summary>
		/// The name of the user. Displayed in the UI. Not used for login though.
		/// </summary>
        [FieldAlias("userName")]
        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }
        
		/// <summary>
		/// The email of the user. Used for login.
		/// </summary>
        [FieldAlias("email")]
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

		/// <summary>
		/// Password hash. Used for login.
		/// </summary>
        [FieldAlias("passwordHash")]
        public string PasswordHash
        {
            get { return passwordHash; }
            set { passwordHash = value; }
        }
		
		/// <summary>
		/// Birthday of the user
		/// </summary>
		[FieldAlias("birthDay")]
    	public DateTime BirthDay
    	{
    		get { return birthDay; }
    		set { birthDay = value; }
    	}
    }
}
