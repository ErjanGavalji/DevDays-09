﻿using System;
using Telerik.OpenAccess;

namespace Telerik.Mvc.Model
{
	/// <summary>
	/// Represents a post object from a forum thread
	/// </summary>
	[Persistent(IdentityField = "id")]
	public class Post
	{
		private Guid id;
		private string content;
		private User author;
		private Thread thread;
		private DateTime createdDate;

		/// <summary>
		/// The date when the post was created
		/// </summary>
		[FieldAlias("createdDate")]
		public DateTime CreatedDate
		{
			get { return createdDate; }
			set { createdDate = value; }
		}

		/// <summary>
		/// The <see cref="Thread" /> object to which the post belongs.
		/// </summary>
		[FieldAlias("thread")]
		public Thread Thread
		{
			get { return thread; }
			set { thread = value; }
		}

		/// <summary>
		/// The unique id of the post. Used as a primary key in the database.
		/// </summary>
		[FieldAlias("id")]
		public Guid Id
		{
			get { return id; }
			set { id = value; }
		}

		/// <summary>
		/// The content of the forum in HTML format.
		/// </summary>
		[FieldAlias("content")]
		public string Content
		{
			get { return content; }
			set { content = value; }
		}

		/// <summary>
		/// The <see cref="User" /> who created the post
		/// </summary>
		[FieldAlias("author")]
		public User Author
		{
			get { return author; }
			set { author = value; }
		}
	}
}