﻿using System;
using System.Collections.Generic;
using Telerik.OpenAccess;

namespace Telerik.Mvc.Model
{
	/// <summary>
	/// Represents a thread in a forum
	/// </summary>
	[Persistent(IdentityField = "id")]
	public class Thread
	{
		private Guid id;
		private string title;
		private string url;
		[Depend]
		private IList<Post> posts;
		private User author;
		private Forum forum;
		private DateTime createdDate;

		/// <summary>
		/// The date when the thread was created
		/// </summary>
		[FieldAlias("createdDate")]
		public DateTime CreatedDate
		{
			get { return createdDate; }
			set { createdDate = value; }
		}
		
		/// <summary>
		/// The <see cref="Forum"/> object to which the thread belongs
		/// </summary>
		[FieldAlias("forum")]
		public Forum Forum
		{
			get { return forum; }
			set { forum = value; }
		}

		/// <summary>
		/// The <see cref="User"/> who created the thread
		/// </summary>
		[FieldAlias("author")]
		public User Author
		{
			get { return author; }
			set { author = value; }
		}

		/// <summary>
		/// The unique id of the post. Used as a primary key in the database.
		/// </summary>
		[FieldAlias("id")]
		public Guid Id
		{
			get { return id; }
			set { id = value; }
		}

		/// <summary>
		/// The title of the forum thread
		/// </summary>
		[FieldAlias("title")]
		public string Title
		{
			get { return title; }
			set { title = value; }
		}

		/// <summary>
		/// The url of the thread e.g. /radcontrols-ajax/grid/sorting-with-radgrid (only the "sorting-with-radgrid" part)
		/// </summary>
		[FieldAlias("url")]
		public string Url
		{
			get { return url; }
			set { url = value; }
		}

		/// <summary>
		/// A collection of <see cref="Post"/> objects which belong to the thread
		/// </summary>
		[FieldAlias("posts")]
		public IList<Post> Posts
		{
			get { return posts; }
			set { posts = value; }
		}
	}
}