﻿using System;
using System.Collections.Generic;
using Telerik.OpenAccess;

namespace Telerik.Mvc.Model
{
	/// <summary>
	/// Represents a forum category object (e.g. "RadControls for ASP.NET Ajax")
	/// </summary>
	[Persistent(IdentityField = "id")]
	public class Category
	{
		private Guid id;
		private string name;
		private string url;
		private IList<Forum> forums;
		private int order;

		/// <summary>
		/// The unique id of the category. Used as a primary key in the database
		/// </summary>
		[FieldAlias("id")]
		public Guid Id
		{
			get { return id; }
			set { id = value; }
		}
		
		/// <summary>
		/// The name of the category. Displayed in the UI
		/// </summary>
		[FieldAlias("name")]
		public string Name
		{
			get { return name; }
			set { name = value; }
		}
		
		/// <summary>
		/// The url of the category e.g. /radcontrols-ajax
		/// </summary>
		[FieldAlias("url")]
		public string Url
		{
			get { return url; }
			set { url = value; }
		}
		
		/// <summary>
		/// Collection of all <see cref="Forum" /> objects belonging to a category.
		/// </summary>
		[FieldAlias("forums")]
		public IList<Forum> Forums
		{
			get { return forums; }
			set { forums = value; }
		}
		
		/// <summary>
		/// Sort order of a forum category
		/// </summary>
		[FieldAlias("order")]
		public int Order
		{
			get { return order; }
			set { order = value; }
		}
	}
}
