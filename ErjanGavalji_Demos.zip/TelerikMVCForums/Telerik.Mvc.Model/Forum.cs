﻿using System;
using System.Collections.Generic;
using Telerik.OpenAccess;

namespace Telerik.Mvc.Model
{
	/// <summary>
	/// Represents a forum object (e.g. "RadGrid")
	/// </summary>
	[Persistent(IdentityField = "id")]
	public class Forum
	{
		private Guid id;
		private string name;
		private string url;
		private IList<Thread> threads;
		private Category category;
		private int order;

		/// <summary>
		/// The <see cref="Category" /> to which a forum belongs
		/// </summary>
		[FieldAlias("category")]
		public Category Category
		{
			get { return category; }
			set { category = value; }
		}

		/// <summary>
		/// The unique id of the forum. Used as a primary key in the database.
		/// </summary>
		[FieldAlias("id")]
		public Guid Id
		{
			get { return id; }
			set { id = value; }
		}

		/// <summary>
		/// The name of the forum e.g. "RadGrid". Displayed in the UI
		/// </summary>
		[FieldAlias("name")]
		public string Name
		{
			get { return name; }
			set { name = value; }
		}

		/// <summary>
		/// The url of the forum e.g. /radcontrols-ajax/grid (only the "grid" part)
		/// </summary>
		[FieldAlias("url")]
		public string Url
		{
			get { return url; }
			set { url = value; }
		}

		/// <summary>
		/// A collection of <see cref="Thread"/> objects which belong to a forum
		/// </summary>
		[FieldAlias("threads")]
		public IList<Thread> Threads
		{
			get { return threads; }
			set { threads = value; }
		}

		/// <summary>
		/// Sort order of the forum.
		/// </summary>
		[FieldAlias("order")]
		public int Order
		{
			get { return order; }
			set { order = value; }
		}
	}
}